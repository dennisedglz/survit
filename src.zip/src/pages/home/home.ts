import { ApiProvider } from './../../providers/api/api';
import { Component } from '@angular/core';
import { NavController, AlertController } from 'ionic-angular';
import { EncuestaPage } from '../encuesta/encuesta';
import { AppDataProvider } from './../../providers/app-data/app-data';
import { AlertProvProvider } from '../../providers/alert-prov/alert-prov';
import { Survey } from '../../models/survey';
import { LoginPage } from '../login/login';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'page-home',
  templateUrl: 'home.html'
})
export class HomePage {
  public surveys: Survey[];
  public surveysToSave: Survey[];
  public day: string = "";
  public month: string = "";
  public message: string = "";
  public months = ['','Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
  constructor(
    public navCtrl: NavController, 
    public appData: AppDataProvider, 
    public api: ApiProvider,
    public alertPrv: AlertProvProvider,
    public alertCtrl: AlertController,
    public storage: Storage
  ) {
    this.getSurveys();
    this.surveys = [];
    this.surveysToSave = [];
  }

  ionViewWillEnter(){ 
    
  }
  
  openSurvey(survey: Survey) {
    this.appData.currentSurvey = survey._id;
    this.navCtrl.push(EncuestaPage, {'survey': survey, 'size': survey.questions.length} , {animate: false});
  }

  getSurveys() {
    this.appData.loading = true;
    this.api.getSurveys()
    .then(data => {
        //this.surveys = data;
        this.filtrarEncuestas(data);
        this.appData.loading = false;
      console.log(this.surveys);
      this.surveys.forEach(element => {
        
        console.log("id "+element._id);
      });
    }).catch(err => {
      this.alertPrv.errorConexion();
      console.log("There was an error");
      console.log(err);

    });  
  }

  filtrarEncuestas(encuestas: Survey[]) {
    let userId = this.appData.userID;
    let today = new Date();
    let endate;
    let i = 0;
   
    encuestas.forEach(e => {
      endate = new Date(e.end_date);
      
      if(today < endate && e.usersId.indexOf(userId) >= 0) {
        var aux = e.end_date.split('-');
        var aux2 = e.start_date.split('-');
        this.surveys[i] = e;
        this.surveys[i].dayDisplay = aux[2]; 
        this.surveys[i].monthDisplay = this.months[Number(aux[1])];
        this.surveys[i].messageDisplay = 'Del ' + aux2[2] + ' de ' + this.months[Number(aux2[1])] + ' al ' + aux[2] + ' de ' + this.months[Number(aux[1])];
        i++;
      }
    });
  }

  logout() {
    this.appData.loading = true;
    this.appData.userID = '';
    this.navCtrl.setRoot(LoginPage);
  }

  saveLocalSurveys(){
    let prompt = this.alertCtrl.create({
      title: 'Under Development',
      message: "Esta funcionalidad aún está en desarrollo.",
      buttons: [
        {
          text: 'Aceptar',
          handler: data => {
          }
        }
      ]
    });
    prompt.present();
    /*this.storage.get('surveys').then((val) => {
      if(val){
        console.log("local: ",val);
        console.log(val)
      }else{
        console.log("Else val");
        let prompt = this.alertCtrl.create({
          title: 'No se encontraron encuestas pendientes',
          message: "Las encuestas ya se han guardado",
          buttons: [
            {
              text: 'Continuar',
              handler: data => {
                this.navCtrl.pop();
              }
            }
          ]
        });
        prompt.present();
      }
    }).catch(() => {
       console.log("err on storage");
      let prompt = this.alertCtrl.create({
        title: 'No se encontraron encuestas pendientes',
        message: "Las encuestas ya se han guardado",
        buttons: [
          {
            text: 'Continuar',
            handler: data => {
              this.navCtrl.pop();
            }
          }
        ]
      });
      prompt.present();
    });*/
  }
}
