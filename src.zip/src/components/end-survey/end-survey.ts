import { Component } from '@angular/core';


@Component({
  selector: 'end-survey',
  templateUrl: 'end-survey.html'
})
export class EndSurveyComponent {


  constructor() {
    
  }

}

