export const AppConstants = {
    LoginURL: 'http://survit.herokuapp.com/loginAPI',
    GetEncuestasURL: 'http://survit.herokuapp.com/createdsurveysjson',
    SaveAnswer: 'http://survit.herokuapp.com/savequestions',
    GetSurveyedID: 'http://survit.herokuapp.com/getUserID',
    SaveAudioImgLatLng: 'http://survit.herokuapp.com/saveUrls',
    NO_DATA_CONNECTION_EVENT: 'noDataConnection',
}